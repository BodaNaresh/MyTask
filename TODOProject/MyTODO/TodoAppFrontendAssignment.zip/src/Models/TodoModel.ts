export class Models {
    ID:number=0;
    Name:string="";
    Status:string="";
    CreationDate?:Date;
    LastUpdatedDate?:Date;
  
}